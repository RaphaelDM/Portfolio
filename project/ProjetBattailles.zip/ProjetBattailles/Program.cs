﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Ports;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace ProjetBattailles
{
    internal class Program
    {


        // Modélisation du jeu : Déclarer les variables 
        public const int PIQUE = 0, CARREAU = 1, COEUR = 2, TREFLE = 3; // couleurs 
        public const int SEPT = 7, HUIT = 8, NEUF = 9, DIX = 10, VALET = 11, DAME = 12,
        ROI = 13, AS = 14; // figures 
       public static int[] carte = new int[32];
       public static int[] couleur = new int[32];
        public static int[] partie = new int[32];
        // Todo - Déclarer les Queue et les stack
        // declaration des mains
        public static Queue<int> listeLULU = new Queue<int>();
        public static Queue<int> listeJosse = new Queue<int>();





        static void Main(string[] args)
            {
            
            CreeCarte();
           

            Console.WriteLine("\n**************Projet_Bataille****************\n");
            
            Console.WriteLine("\nLe jeu de carte : \n");
            AfficherLesCartes();

            Console.Write("\n\n");
            Console.WriteLine("\nLe jeu de carte melanger :\n");
            BattreCarte();
            AfficherCarteDeLaPartie();
            Console.Write("\n\n");
            Console.WriteLine("\nDistribution des cartes a Lulu et Josse : \n");
            DistribuerJeu();
            Console.Write("\n\n");
            Console.WriteLine("\nDeposer les cartes :\n");
            DeposerCarte();
            Console.ReadKey();
            }

        // Afficher cartes
 

        // Créer cartes
        public static void CreeCarte()
        {
            int i = 0;// indice de la carte 
            for (int c = 0; c < 4; c++)// pour chaque couleur                            
            {
                for (int f = 7; f < 15; f++)// pour chaque figure
                {

                    carte[i] = f;// sa figure 
                    couleur[i] = c;// sa couleur 
                    i++;
                }
            }

        }


        //Affichez cartes en lettre 


        static string AfficherCarte(int pi)
        {
            int fig = carte[pi];
            string figure = fig.ToString();



            if (fig == VALET) figure = "VALET";
            if (fig == DAME) figure = "DAME";
            if (fig == ROI) figure = "ROI";
            if (fig == AS) figure = "AS";



            int coul = couleur[pi];
            string colori = "";



            if (coul == PIQUE) colori = "Pique";
            if (coul == CARREAU) colori = "Carreau";
            if (coul == COEUR) colori = "Coeur";
            if (coul == TREFLE) colori = "Trefle";



            return (figure + " de " + colori +" ");
        }



        /// <summary>
        /// AfficherLesCartes : affiche toutes les cartes du jeu 
        /// </summary>
        static void AfficherLesCartes()
        {
            int j = 0;
            for (int i = 0; i < 32; i++)
            {
                if (j % 8 == 0) Console.WriteLine();
                Console.Write("{0}|  ", AfficherCarte(i));
                j++;

            }
        }

        static void BattreCarte()
        {
            
            bool[] okRd = new bool[32]; // savoir si le numéro a été tiré 
            for (int i = 0; i < 32; i++)
            {
                okRd[i] = false; // init à false 
                partie[i] = -1;  // init tableau partie 
            }



            Random rd = new Random();
            int val = rd.Next(32);   // init une première fois 



            for (int i = 0; i < 30; i++)
            {
                // tirer au sort un autre numéro si déja sorti 
                do
                {
                    val = rd.Next(32);
                } while (Array.Exists(partie, element => element == val));
                partie[i] = val;
                okRd[val] = true;   // trouvé 
            }
            // on fait les deux dernières à la main (sinon mouline trop longtemps)
            // on doit donc chercher les deux dernières valeurs non tirées 
            int posA = Array.FindIndex(okRd, element => element == false);
            partie[30] = posA;
            int posB = Array.FindIndex(okRd, posA + 1, element => element == false);
            partie[31] = posB;

            

    
        }

       static void AfficherCarteDeLaPartie()
        {
            for (int i = 0; i < 32; i++)
            {
                Console.Write("{0}| ", AfficherCarte(partie[i]));
            }
        }

        public static void DistribuerJeu()
        {
         

           

            for (int i = 0; i < 32; i++)
            if(i%2 == 0)
                {
                    listeLULU.Enqueue(partie[i]);
                  
                }
                else
                {
                    
                    listeJosse.Enqueue(partie[i]);
                  
                }

            Console.WriteLine("Le jeu de carte de Lulu: \n");
            foreach(int i in listeLULU)
            {
                Console.Write(AfficherCarte(partie[i]) + "|  ");
            }
            Console.WriteLine();
            Console.WriteLine("\nLe jeu de carte de Josse: \n");
            foreach (int i in listeJosse)
            {
                Console.Write(AfficherCarte(partie[i])+"|  ");
            }

        }

        public static void DeposerCarte()
        {

            {
                string color = "";
                string figures = "";

                string color2 = "";
                string figures2 = "";

                 int Josse = listeJosse.Dequeue();
                int Lulu = listeLULU.Dequeue();

                if (Josse < 8)
                {
                    color = "Pique";
                }
                else if (Josse >= 8 && Josse < 16)
                {
                    color = "Carreau";
                }
                else if (Josse >= 16 && Josse < 24)
                {
                    color = "Coeur";
                }
                else if (Josse >= 24 && Josse < 32)
                {
                    color = "Trefle";
                }

                if (Josse == 0 | Josse == 8 | Josse == 16 | Josse == 24)
                {
                    figures = "7";
                }
                else if (Josse == 1 | Josse == 9 | Josse == 17 | Josse == 25)
                {
                    figures = "8";
                }
                else if (Josse == 2 | Josse == 10 | Josse == 18 | Josse == 26)
                {
                    figures = "9";
                }
                else if (Josse == 3 | Josse == 11 | Josse == 19 | Josse == 27)
                {
                    figures = "10";
                }
                else if (Josse == 4 | Josse == 12 | Josse == 20 | Josse == 28)
                {
                    figures = "Valet";
                }
                else if (Josse == 5 | Josse == 13 | Josse == 21 | Josse == 29)
                {
                    figures = "Dame";
                }
                else if (Josse == 6 | Josse == 14 | Josse == 22 | Josse == 30)
                {
                    figures = "Roi";
                }
                else if (Josse == 7 | Josse == 15 | Josse == 23 | Josse == 31)
                {
                    figures = "As";
                }

                if (Lulu < 8)
                {
                    color2 = "Pique";
                }
                else if (Lulu >= 8 && Lulu < 16)
                {
                    color2 = "Carreau";
                }
                else if (Lulu >= 16 && Lulu < 24)
                {
                    color2 = "Coeur";
                }
                else if (Lulu >= 24 && Lulu < 32)
                {
                    color2 = "Trefle";
                }

                if (Lulu == 0 | Lulu == 8 | Lulu == 16 | Lulu == 24)
                {
                    figures2 = "7";
                }
                else if (Lulu == 1 | Lulu == 9 | Lulu == 17 | Lulu == 25)
                {
                    figures2 = "8";
                }
                else if (Lulu == 2 | Lulu == 10 | Lulu == 18 | Lulu == 26)
                {
                    figures2 = "9";
                }
                else if (Lulu == 3 | Lulu == 11 | Lulu == 19 | Lulu == 27)
                {
                    figures2 = "10";
                }
                else if (Lulu == 4 | Lulu == 12 | Lulu == 20 | Lulu == 28)
                {
                    figures2 = "Valet";
                }
                else if (Lulu == 5 | Lulu == 13 | Lulu == 21 | Lulu == 29)
                {
                    figures2 = "Dame";
                }
                else if (Lulu == 6 | Lulu == 14 | Lulu == 22 | Lulu == 30)
                {
                    figures2 = "Roi";
                }
                else if (Lulu == 7 | Lulu == 15 | Lulu == 23 | Lulu == 31)
                {
                    figures2 = "As";
                }


                Console.Write("\nCarte deposer de Josse : " + figures + "  " + color);
                Console.Write("\t Carte deposer par Lulu : " + figures2 + "  " + color2);

                // gerrer le tour 

                if (Josse > Lulu)
                {
                    Console.WriteLine("");
                    Console.WriteLine("Jose gagne le tour");

                }
                else if(Lulu == Josse)
                {
                    Console.WriteLine("");
                    Console.WriteLine("Egaliter rejouer ");

                }
                else { 
                    Console.WriteLine("");
                    Console.WriteLine("Lulu gagne le tour "); 
                }


            }

        }



    }

        
}



    
     

