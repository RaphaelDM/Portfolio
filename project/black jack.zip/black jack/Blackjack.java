import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class Blackjack {

    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        System.out.println("Bienvenue au BlackJack !\n");
        int wins = 0;
        int ties = 0;
        int losses = 0;

        boolean playAgain = true;

        while (playAgain) {
            List<String> deck = createDeck();
            Collections.shuffle(deck);
            List<String> playerCards = new ArrayList<>();
            List<String> dealerCards = new ArrayList<>();
            playerCards.add(drawCard(deck));
            playerCards.add(drawCard(deck));
            dealerCards.add(drawCard(deck));
            dealerCards.add(drawCard(deck));
            boolean playerTurn = true;
            boolean dealerTurn = true;
            while (true) {
                if (playerTurn) {
                    System.out.println("Vos cartes sont :");
                    displayCards(playerCards);
                    int total = getTotal(playerCards);
                    System.out.println("Total : " + total);
                    System.out.println("--------------------------------------\n");
                    if (total > 21) {
                        System.out.println("Vous avez dépassé 21, vous avez perdu !");
                        losses++;
                        break;
                    }
                    System.out.println("Le croupier a un " + dealerCards.get(0) + " face visible");
                    System.out.println("--------------------------------------");
                    System.out.println("Voulez-vous prendre une autre carte ? (oui ou non)");
                    String answer = scanner.nextLine();
                    if (answer.equals("oui")) {
                        playerCards.add(drawCard(deck));
                    } else {
                        playerTurn = false;
                    }
                }
                if (dealerTurn) {
                    int total = getTotal(dealerCards);
                    if (total < 17) {
                        System.out.println("Le croupier prend une autre carte");
                        dealerCards.add(drawCard(deck));
                    } else {
                        System.out.println("Le croupier reste");
                        dealerTurn = false;
                    }
                }
                System.out.println();
                if (!playerTurn && !dealerTurn) {
                    int playerTotal = getTotal(playerCards);
                    int dealerTotal = getTotal(dealerCards);
                    System.out.println("Vos cartes :");
                    displayCards(playerCards);
                    System.out.println("Total : " + playerTotal + "\n");
                    System.out.println("Cartes du croupier :\n");
                    displayCards(dealerCards);
                    System.out.println("Total : " + dealerTotal + "\n");
                    if (playerTotal > dealerTotal) {
                        System.out.println("Vous avez gagné !\n");
                        System.out.println("--------------------------------------");
                        wins++;

                    }

                    else if (playerTotal == dealerTotal) {
                        System.out.println("Match nul !\n");
                        System.out.println("--------------------------------------");
                        ties++;
                    } else if (dealerTotal > 21) {
                        System.out.println("Le croupier a Bruler !\n");
                        System.out.println("--------------------------------------");
                        wins++;
                    }

                    else {
                        System.out.println("Le croupier a gagné !\n");
                        System.out.println("--------------------------------------");
                        losses++;
                    }
                    break;
                }
            }

            System.out
                    .println("Vous avez " + wins + " victoires, " + ties + " matchs nuls et " + losses + " défaites.");
            System.out.println("--------------------------------------");
            System.out.println("Voulez-vous jouer à nouveau ? (oui ou non)\n");
            String answer = scanner.nextLine();
            playAgain = answer.equals("oui");
        }
        System.out.println("--------------------------------------");
        System.out.println("Merci d'avoir joué au BlackJack !");
    }

    private static List<String> createDeck() {
        List<String> deck = new ArrayList<>();
        String[] suits = { "Coeur", "Carreau", "Trèfle", "Pique" };
        String[] ranks = { "As", "2", "3", "4", "5", "6", "7", "8", "9", "10", "Valet", "Dame", "Roi" };
        for (String suit : suits) {
            for (String rank : ranks) {
                deck.add(rank + " de " + suit);
            }
        }
        return deck;
    }

    private static String drawCard(List<String> deck) {
        return deck.remove(0);
    }

    private static void displayCards(List<String> cards) {
        for (String card : cards) {
            System.out.println("- " + card);
        }
    }

    private static int getTotal(List<String> cards) {
        int total = 0;
        boolean hasAce = false;
        for (String card : cards) {
            String rank = card.split(" ")[0];
            if (rank.equals("As")) {
                hasAce = true;
                total += 11;
            } else if (rank.equals("Valet") || rank.equals("Dame") || rank.equals("Roi")) {
                total += 10;
            } else {
                total += Integer.parseInt(rank);
            }
        }
        if (hasAce && total > 21) {
            total -= 10;
        }
        return total;
    }

}
