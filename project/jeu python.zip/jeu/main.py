import pygame
pygame.init()
from game import Game



#generer fenetre jeu
pygame.display.set_caption("Comet fall Game")
screen =  pygame.display.set_mode((1080 , 720))

#importer l'immage de l'arriere plan 
background = pygame.image.load('assets/bg.jpg')

#cherger jeu
game = Game()



running = True

#boucle  pour garder la fenetre ouverte tant que  running = true

while running:
    #appliquer l'arriere plan du jeu
    screen.blit(background,(0,-200))
    #appliquer image du joueur
    screen.blit(game.player.image ,game.player.rect)

    #recuperer les projectiles
    for projectille in game.player.all_projectiles:
        projectille.move()

    #recuperer les monstres
    for monster in game.all_monsters:
        monster.forward()    

    #appliquer l'ensemble des images de mon groupe de projectiles
    game.player.all_projectiles.draw(screen)


    #afficher monstre
    game.all_monsters.draw(screen)
    
    #verifier si le joueur  veux aller gauche ou droite
    if game.pressed.get(pygame.K_RIGHT) and game.player.rect.x + game.player.rect.width < screen.get_width():
        game.player.move_right()
    elif game.pressed.get(pygame.K_LEFT) and game.player.rect.x > 0:
        game.player.move_left()

    



    #mettre a jour l'ecran
    pygame.display.flip()
    
    
    #si le joueur ferme la fenetre
    for event in pygame.event.get():
        #verifier que l'venement et fermer de fenetre
        if event.type == pygame.QUIT:
            running = False
            pygame.quit()
            print("Fermeture du jeu")
        #detecter si un joueur lache une touche du clavier 
        elif event.type == pygame.KEYDOWN:
            game.pressed[event.key] = True

            #si la touche espace et appuyer pour lancer projectille
            if event.key == pygame.K_SPACE:
                game.player.launch_projectile()
                

           

        elif event.type == pygame.KEYUP:
            game.pressed[event.key] = False

           
      